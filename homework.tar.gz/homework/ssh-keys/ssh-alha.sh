#!/bin/sh

ssh -i ./ansible_id_rsa ansible@172.16.100.140
