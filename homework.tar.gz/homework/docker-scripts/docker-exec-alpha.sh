#!/bin/bash

docker exec -it alpha /bin/bash
