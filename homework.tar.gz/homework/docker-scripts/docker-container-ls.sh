#!/bin/bash

docker container ls --all
