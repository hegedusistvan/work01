#!/bin/bash

#docker network inspect bridge

docker network inspect conti-test
