#!/bin/bash

docker images
