#!/bin/bash

docker network ls
